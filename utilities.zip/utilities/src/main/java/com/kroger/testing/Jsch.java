package com.kroger.testing;

import com.jcraft.jsch.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class Jsch {

    private Session session;
    private Channel channel;
    private String host, user, password;
    private int portnumber;
    private ChannelSftp channelSftp;
    private ChannelExec channelexec;

    public Session Create_Session(String host, String user, String password, int portnumber) throws Exception {
        java.util.Properties config = new java.util.Properties();
        config.put("StrictHostKeyChecking", "no");
        JSch jsch = new JSch();
        this.user = user;
        this.password = password;
        this.host = host;
        this.portnumber = portnumber;
        this.session = jsch.getSession(user, host, portnumber);
        session.setPassword(password);
        session.setConfig(config);
        session.connect();
        return session;
    }




    public void channel_sftp(String from, String to, String filename) throws Exception {
        this.channel = session.openChannel("sftp");
        channel.connect();
        ChannelSftp channelSftp = (ChannelSftp) channel;
        channelSftp.cd(to);
        File file= new File(from+filename);
        if (file.isFile()) {
            InputStream inputStream = new FileInputStream(file);
            File f = new File(file.getName());
            channelSftp.put(inputStream, to+f.getName());
        }
        //channel.disconnect();
    }

    public void Channel_Execute(String command1) throws Exception {
            this.channel=session.openChannel("exec");
            ((ChannelExec)channel).setCommand(command1);
            channel.setInputStream(null);
            ((ChannelExec)channel).setErrStream(System.err);

            InputStream in=channel.getInputStream();
            channel.connect();
            byte[] tmp=new byte[1024];
            while(true) {
                while (in.available() > 0) {
                    int i = in.read(tmp, 0, 1024);
                    if (i < 0) break;
                    System.out.print(new String(tmp, 0, i));
                }
                if (channel.isClosed()) {
                    System.out.println("exit-status: " + channel.getExitStatus());
                    //channel.disconnect();
                    break;
                }

            }
    }
}
