package com.kroger.testing;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.Session;

public class Imp_Jsch {

    public static void main(String args[])throws Exception {
    Jsch jsch_lib= new Jsch();
    //String commnad ="cd payload && /webApps/kafka/bin/kafkacat -H payload_version=1.0.0 -H batch_number=test -H action=add -P -l -b 10.254.227.220:9092 -t recipe-ingredient heartbeat.json";
    String commnad=" /webApps/kafka/bin/kafka-console-producer.sh --broker-list 10.254.227.220:9092 --producer.config /webApps/kafka/security.conf --topic recipe-ingredient < /home/speldply/payload/heartbeat.json";
       Session session= jsch_lib.Create_Session("u060speld802.kroger.com","speldply","wxCEhqrjW",22);


       jsch_lib.channel_sftp("C:\\Users\\kon8040\\Desktop\\","/home/speldply/payload/","payload_dhar.json");
        //jsch_lib.Channel_Execute("/webApps/kafka/bin/kafkacat -H payload_version=1.0.0 -H batch_number=test -H action=add -P -l -b 10.252.78.32:9092 -t recipe-ingredient /home/speldply/payload/heartbeat.json");
        jsch_lib.Channel_Execute(commnad);
        //ch.disconnect();
       session.disconnect();
    } }


